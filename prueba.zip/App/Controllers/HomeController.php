<?php

namespace App\Controllers;

class HomeController {
    public function index() {
        echo "Bienvenido a mi proyecto MVC con TDD";
    }
}
