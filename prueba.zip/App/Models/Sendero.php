<?php

namespace App\Models;

class Sendero
{
    // Aquí irán las propiedades y métodos del modelo Sendero
}
