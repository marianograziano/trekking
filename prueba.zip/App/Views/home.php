<!DOCTYPE html>
<html>
<head>
    <title>Mi Proyecto</title>
    <link rel="stylesheet" type="text/css" href="/css/style.css">
</head>
<body>
    <h1>Bienvenido a mi proyecto MVC con TDD</h1>
</body>
</html>
